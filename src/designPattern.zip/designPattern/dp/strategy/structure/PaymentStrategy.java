package dp.strategy.structure;

public interface PaymentStrategy {
    void pay(int amount);
}
