package dp.observer.structure;

public interface Observer {
    void update(float temperature);
}
