package dp.observer;

public class MainObserver {

	public static void main(String[] args) {
		// Le code c'est ici !
	}

}
