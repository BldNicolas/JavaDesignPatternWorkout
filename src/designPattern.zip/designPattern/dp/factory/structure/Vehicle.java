package dp.factory.structure;

public interface Vehicle {
    void startEngine();
}
