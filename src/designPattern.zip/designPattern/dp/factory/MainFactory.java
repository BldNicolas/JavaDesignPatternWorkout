package dp.factory;

public class MainFactory {

	public static void main(String[] args) {
		// Code me please :(
		
	}
	
}
