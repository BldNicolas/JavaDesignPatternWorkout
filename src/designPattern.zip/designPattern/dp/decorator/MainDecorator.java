package dp.decorator;

public class MainDecorator {

	public static void main(String[] args) {
		// Code Here !
	}
}
