package dp.singleton;

public class MainSingleton {

	public static void main(String[] args) {
		// Le code c'est ici !
		Logger log = Logger.getInstance();

		Logger log2 = Logger.getInstance();

	}

}
